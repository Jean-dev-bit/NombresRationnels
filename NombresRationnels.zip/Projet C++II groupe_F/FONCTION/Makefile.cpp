#include <iostream>
#include"FONCTION.h"
#include <iomanip>
using namespace std;

//Vérificattion d'un nombre rationnel
void rationnel(int &a){
    while(a==0){
        cout<<"Veuillez entrer un denominateur different de zero : ";
        cin>>a;
    }
}
//Plus grand commun Diviseur
int pgcd(int x,int y){
    while(x != y)
    {
    if(x>y)
    x-=y;
    else
    y -= x;
    }
    return x;
}

// Vérification d'un nombre rationnel normalisé
void rationnelNormalise(int &a,int &b){
    while(b<=0 || pgcd(a,b)!=1){
        cout<<"Voulant un  nombre rationnel normalise, le denominateur doit etre superieur a 0 et le PDCG des nombres saisis doit etre egal a 1. \n"<<"Veuillez entrer de nouveaux nombres "<<endl;
        cout<<"Entrer le nouveau numerateur : ";
        cin>>a;
        cout<<"Entrer le nouveau denominateur : ";
        cin>>b;
    }
}

// Affichage des nombres
void Affichage_Nombre (int a, int b){
    cout<<"["<<a<<","<<b<<"]";
}

// Fonction qui demande à l'utilisateur les nombres rationnels
int demandeRationnel (int &num, int &den){
    cout<<endl;
    cout<<"Entrer le numerateur du nombre rationnel : ";
    cin>>num;
    cout<<endl;
    cout<<"Entrer le denominateur du nombre rationnel : ";
    cin>>den;
    cout<<endl;
    rationnel(den);
    return num, den;
}

// Fonction qui demande à l'utilisateur les nombres rationnels Normalisés
int demandeRationnel_Normalise (int &numr, int &denr){
    cout<<endl;
    cout<<"Entrer le numerateur du nombre rationnel normalise : ";
    cin>>numr;
    cout<<endl;
    cout<<"Entrer le denominateur du nombre rationnel normalise : ";
    cin>>denr;
    cout<<endl;
    rationnelNormalise(numr, denr);
    return numr, denr;
}

// Fonction qui demande un entier quelconque
int demandeEntier (int &entier){
    cout<<"Entrer le nombre entier : ";
    cin>>entier;
    return entier;
}

// L'addition de deux rationnels
void Addition(int a1, int b1, int a2, int b2){
 int num=(a1*b2)+(a2*b1);
  int den=b1*b2;
    cout<<"["<<num<<","<<den<<"]"<<endl;
}
//Multiplication de deux rationnels
void Multiplication(int a1, int b1,int a2, int b2){
    int num=a1*a2;
     int den=b1*b2;
    cout<<"["<<num<<","<<den<<"]"<<endl;
}
//Division de deux rationnels
void Division(int a1, int b1,int a2, int b2){
int num=a1*b2;
  int den=b1*a2;
    cout<<"["<<num<<","<<den<<"]"<<endl;
}

//Soustraction de deux rationnels
void Soustraction(int a1, int b1,int a2, int b2){
 int num=(a1*b2)-(a2*b1);
  int den=b1*b2;
    cout<<"["<<num<<","<<den<<"]"<<endl;
}

//Inverse d'un rationnel

void Inverse(int a, int b){
 int num=a;
  int den=b;
   cout<<"["<<den<<","<<num<<"]"<<endl;
}
//Normalisation

    void Normalisation(int a, int b){
    int num = a/pgcd(a,b);
    int den = b/pgcd(a,b);

        cout<<"["<<num<<","<<den<<"]"<<endl;
   }

// Somme & Produit de n rationnels

void Somme_Multiplication (int m){
 int num, den;
 int som_num=0, som_den=1;
  int mul_num=1;
  int mul_den=1;
  for (int i=0; i<m; i++){
      cout<<"Entrer le numerateur du "<<i+1<<" nombre : ";
      cin>>num;
      cout<<"Entrer le denominateur du "<<i+1<<" nombre : ";
      cin>>den;
      rationnel(den);
    som_num=(som_num*den)+(som_den*num);
    som_den=som_den*den;
       mul_num*=num;
       mul_den*=den;
       cout<<"Nombre rationnel "<<i+1<<" : ";
       Affichage_Nombre(num,den);
       cout<<endl;
      }
  cout<<endl<<"La somme des nombres saisis donne : "<<"["<<som_num<<","<<som_den<<"]"<<endl<<endl;
 cout<<"Le produit des nombres rationnels saisir est egal a : "<<"["<<mul_num<<","<<mul_den<<"]"<<endl;
}
//Afficher sous le format num/den

void Affichage_Format (int a, int b){
     cout<<a<<"/"<<b<<endl;
}
//Comparaison de deux rationnels

void Compare(int a1, int b1, int a2, int b2){
    double r1;
    r1= double(a1)/b1;
    rationnel(b1);
    cout<<endl;
    double r2;
    r2=double(a2)/b2;
    rationnel(b2);
    if (r1<r2){
        cout<<" 1 "<<endl;
    }else{
        cout<<" 0 ";
    }
}

//Classement ou Tri par ordre croissant

void Classement (int n){
    double tab[n];
    double k;
    int m;
      for (int i=0; i<n; i++){
          cout<<"Entrer le numerateur du "<<i+1<<" nombre rationnel : ";
          cin>>k;
          cout<<"Entrer le denominateur du "<<i+1<<" nombre rationnel : ";
          cin>>m;
          rationnel(m);
          tab[i]=k/m;
          Affichage_Nombre(k,m);
          cout<<"\t\t"<<endl;
    }
            for (int i=0; i<n; i++){
                for (int j=(i+1); j<n; j++){
                  if (tab[j]<tab[i]){
                      double temp=tab[i];
                         tab[i]=tab[j];
                          tab[j]=temp;

            }
        }
    }
    cout<<endl<<"------Voici en odre croissant les nombres que vous avez saisis-----"<<endl;
    cout<<endl;
     for (int i=0; i<n; i++){
         cout<<setw(15)<<tab[i];

    }
}



