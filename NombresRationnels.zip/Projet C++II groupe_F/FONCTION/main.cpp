#include <QCoreApplication>
#include <iostream>
#include <cmath>
#include <iomanip>
#include "FONCTION.h"
using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    int choix;
    string secondChoix;
    cout<<"----------------------Bienvenu dans notre Programme---------------------------"<<endl;
    cout<<"---------Operation sur les rationnels representes par des tableaux------------"<<endl<<endl;
    cout<<"-----Voici les operations que constituent notre programme-----"<<endl;
    cout<<"1. Addition de deux nombres rationnels \n"<<"2. Addition d'un nombre rationnel et d'un nombre entier \n"<<"3. Addition de deux nombres rationnels normalises \n"<<"4. Multiplication de deux nombres rationnels \n"<<"5. Multiplication d'un nombre rationnel et un nombre entier \n"<<"6. Multiplication de deux nombres rationnels normalises \n"<<"7. Division de deux nombres rationnels \n"<<"8. Division d'un nombre rationnel et d'un nombre entier \n"<<"9. Division de deux nombres rationnels normalises \n"<<"10. Soustration de deux nombres rationnels \n"<<"11. Soustraction d'un nombre rationnel et d'un nombre entier \n"<<"12. Soustration de deux nombres rationnels normalises \n"<<"13. Inverse d'un nombre rationnel \n"<<"14. Normalisation d'un nombre rationnel \n"<<"15. Somme et Produit de n nombre rationnels \n"<<"16. Affichage d'un nombre rationnel sous le format \n"<<"17. Comparaison de deux nombres rationnels \n"<<"18. Classement de n nombres rationnels \n"<<endl;

    do{
        cout<<"Veuillez choisir l'operation voulue : ";
        cin>>choix;
        switch (choix) {
        case 1 : {
           int num, den;
           int num1, den1;
         demandeRationnel(num, den);
         demandeRationnel(num1, den1);
         cout<<"Premier nombre rationnel : ";
         Affichage_Nombre(num,den);
         cout<<"\t \t";
         cout<<" Deuxieme nombre rationnel : ";
         Affichage_Nombre(num1,den1);
         cout<<endl;
            cout<<"L' Addition des deux nombres rationnels donne : ";
                Addition(num, den, num1, den1);
                cout<<endl;
        break;
        }
       case 2 : {
            int Nbre;
             int num, den;
            demandeRationnel(num, den);
            demandeEntier(Nbre);
             cout<<"Nombre rationnel saisis : ";
              Affichage_Nombre(num,den);
             cout<<"\t \t";
              cout<<"Le nombre entier saisis : "<<Nbre<<endl<<endl;
            cout<<"L'Addition du nombre rationnel avec le nombre entier donne : ";
              Addition(num, den, Nbre);
                cout<<endl;
            break;
        }
    case 3 :{
           int num, den;
           int num1, den1;
          demandeRationnel_Normalise(num,den);
          demandeRationnel_Normalise(num1,den1);
          cout<<"Premier nombre rationnel normalise : ";
          Affichage_Nombre(num,den);
          cout<<"\t\t";
          cout<<"Deuxieme nombre rationnel normalise : ";
          Affichage_Nombre(num1,den1);
          cout<<endl;
            cout<<"L'Addition des deux nombres rationnels normalises donne : ";
               Addition( num, den, num1, den1);
                 cout<<endl;
            break;
              }
     case 4 :{
           int num, den;
           int num1, den1;
           demandeRationnel(num,den);
           demandeRationnel(num1,den1);
           cout<<"Premier nombre rationnel : ";
           Affichage_Nombre(num,den);
           cout<<"\t \t";
           cout<<" Deuxieme nombre rationnel : ";
           Affichage_Nombre(num1,den1);
           cout<<endl;
            cout<<" La Multiplication des deux nombres rationnels donne : ";
                Multiplication(num, den,num1, den1);
                cout<<endl;
            break;
              }
            case 5 :{
            int Nbre;
            int num, den;
            demandeRationnel(num,den);
            demandeEntier(Nbre);
             cout<<" Nombre rationnel saisir: ";
            Affichage_Nombre(num,den);
            cout<<"\t\t";
            cout<<"Le nombre entier saisis : "<<Nbre<<endl;
            cout<<"La Multiplication  du nombre rationnel et du nombre entier donne : ";
                Multiplication(num, den, Nbre);
                cout<<endl;
            break;
              }
    case 6 :{
            int num, den;
            int num1, den1;
            demandeRationnel_Normalise(num,den);
            demandeRationnel_Normalise(num1,den1);
            cout<<"Premier nombre rationnel normalise : ";
            Affichage_Nombre(num,den);
            cout<<"\t\t";
            cout<<" Deuxieme nombre rationnel normalise : ";
            Affichage_Nombre(num1,den1);
            cout<<endl;
            cout<<"La Multiplication des deux nombres rationnels normalises donne : ";
                Multiplication( num, den,num1, den1);
                cout<<endl;
            break;
                }
        case 7 :{
            int num, den;
            int num1, den1;
            demandeRationnel(num,den);
            demandeRationnel(num1,den1);
            cout<<"Premier nombre rationnel : ";
            Affichage_Nombre(num,den);
            cout<<"\t \t";
            cout<<" Deuxieme nombre rationnel : ";
            Affichage_Nombre(num1,den1);
            cout<<endl;
            cout<<" La Division des deux nombres rationnels donne : ";
                Division(num, den, num1, den1);
                cout<<endl;
            break;
            }
          case 8 : {
          int Nbre;
            int num, den;
            demandeRationnel(num,den);
            demandeEntier(Nbre);
            cout<<"Nombre rationnel saisis : ";
            Affichage_Nombre(num,den);
            cout<<"\t\t";
            cout<<"Le nombre entier : "<<Nbre<<endl;
            cout<<"La Division du nombre rationnel et du nombre entier donne ";
            Division(num, den, Nbre);
            cout<<endl;
            break;
            }
        case 9 :{
            int num, den;
            int num1, den1;
            demandeRationnel_Normalise(num,den);
            demandeRationnel_Normalise(num1,den1);
            cout<<"Premier nombre rationnel normalise : ";
            Affichage_Nombre(num,den);
            cout<<"\t\t";
            cout<<" Deuxieme nombre rationnel normalise : ";
            Affichage_Nombre(num1,den1);
            cout<<endl;
            cout<<"La Division des deux rationnels normalises donne : ";
             Division(num, den, num1, den1);
             cout<<endl;
            break;
            }
        case 10 :{
            int num, den;
            int num1, den1;
            demandeRationnel(num,den);
            demandeRationnel(num1,den1);
            cout<<"Premier nombre rationnel : ";
            Affichage_Nombre(num,den);
            cout<<"\t \t";
            cout<<" Deuxieme nombre rationnel : ";
            Affichage_Nombre(num1,den1);
            cout<<endl;
            cout<<"La Soustration des deux nombres rationnels donnes : ";
            Soustraction(num, den, num1, den1);
            cout<<endl;
            break;
            }
       case 11 :{
            int Nbre;
            int num, den;
            demandeRationnel(num,den);
            demandeEntier(Nbre);
             cout<<" Nombre rationnel saisis : ";
            Affichage_Nombre(num,den);
            cout<<"\t\t";
            cout<<"Le nombre entier saisis : "<<Nbre<<endl;
            cout<<" La Soustraction d'un nombre rationnel et du nombre entier donne : ";
            Soustraction(num, den, Nbre);
            cout<<endl;
            break;
            }
        case 12 :{
            int num, den;
            int num1, den1;
            demandeRationnel_Normalise(num,den);
            demandeRationnel_Normalise(num1,den1);
            cout<<"Premier nombre rationnel normalise : ";
            Affichage_Nombre(num,den);
            cout<<"\t\t";
            cout<<" Deuxieme nombre rationnel normalise : ";
            Affichage_Nombre(num1,den1);
            cout<<endl;
            cout<<"La Soustration des deux nombres rationnels normalises donne : ";
            Soustraction(num, den, num1, den1);
             cout<<endl;
            break;
            }
        case 13 :{
          int num, den;
          demandeRationnel(num,den);
          cout<<" Nombre rationnel  saisis : ";
          Affichage_Nombre(num,den);
          cout<<"\t\t";
          cout<<"Son Inverse donne : ";
            Inverse(num, den);
            cout<<endl;
            break;
            }
          case 14 :{
          int num, den;
          demandeRationnel(num,den);
          cout<<" Nombre rationnel saisis : ";
          Affichage_Nombre(num,den);
          cout<<"\t\t";
          cout<<"La normalisation du nombre rationnel saisis est : ";
          Normalisation(num,den);
          cout<<endl;
            break;
            }
        case 15 :{
       int n;
            cout<<"Entrer le nombre de nombres que vous souhaitez saisir : ";
             cin>>n;
             Somme_Multiplication(n);
             cout<<endl;
            break;
            }
        case 16 :{
          int num, den;
          demandeRationnel(num,den);
          cout<<" Nombre rationnel saisis : ";
         Affichage_Nombre(num,den);
         cout<<"\t\t";
            cout<<" L'affichage du nombre rationnel saisis sous le format donne : ";
             Affichage_Format(num, den);
                cout<<endl;
            break;
            }
        case 17 :{
            int num, den;
            int num1, den1;
            demandeRationnel(num,den);
            demandeRationnel(num1,den1);
            cout<<"Premier nombre rationnel : ";
            Affichage_Nombre(num,den);
            cout<<"\t \t";
            cout<<" Deuxieme nombre rationnel : ";
            Affichage_Nombre(num1,den1);
            cout<<endl;
            cout<<endl;
            cout<<"La comparaison des deux nombres rationnels donne : " ;
            Compare(num,den,num1,den1);
            cout<<endl;
            break;
            }
        case 18 :{
        int n;
         cout<<"Entrer le nombre de nombres rationnel que vous voulez trier : ";
            cin>>n;
            Classement(n);
            break;
            }
        default:{
            cout<<"Erreur de choix."<<endl;
            break;
        }
   }
        cout<<endl;
        cout<<endl;
        cout<<"Voulez-vous continuer : ";
        cin>>secondChoix;
        cout<<endl;
    }while(secondChoix=="Oui" || secondChoix=="oui" || secondChoix=="OUI");
    cout<<"FIN DE PROGRAMME ! ";




    return a.exec();
}
