#ifndef FONCTION_H
#define FONCTION_H









void rationnel(int &a);
int pgcd(int x, int y);
void rationnelNormalise(int &a, int &b);
void Affichage_Nombre (int a, int b);
int demandeRationnel (int &num, int &den);
int demandeRationnel_Normalise (int &num, int &den);
int demandeEntier (int &entier);
void Addition(int a1,int b1,int a2=0, int b2=1);
void Multiplication(int a1, int b1,int a2=1, int b2=1);
void Division(int a1, int b1,int a2, int b2=1);
void Soustraction(int a1, int b1,int a2, int b2=1);
void Inverse(int a, int b);
void Normalisation(int a, int b);
int Somme (int a, int b);
void Somme_Multiplication (int m);
void Affichage_Format(int a, int b);
void Compare(int a1, int b1, int a2, int b2);
void Classement (int n);













#endif // FONCTION_H
