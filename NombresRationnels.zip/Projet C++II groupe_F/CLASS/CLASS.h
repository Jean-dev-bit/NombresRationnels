#ifndef CLASS_H
#define CLASS_H




class Rationnel
{
public:
    Rationnel() {}
    Rationnel(int m = 0,unsigned int p = 1):m_numerateur(m),m_denominateur(p){}
    Rationnel(int entier):m_numerateur(entier),m_denominateur(1){}
    // Recuperer le numérateur
    int getNumerator(){
        return m_numerateur;
    }
    // Recuperer le dénominateur
    int getDenominator(){
        return m_denominateur;
    }
     friend Rationnel operator+(Rationnel& f1, Rationnel& f2);
     friend Rationnel operator-(Rationnel& f1, Rationnel& f2);
     void simplify();
     friend Rationnel operator*(Rationnel& f1, Rationnel& f2);
     friend Rationnel operator/(Rationnel& f1, Rationnel& f2);
     friend Rationnel operator*(Rationnel& f1, int& m);
     friend Rationnel operator+(Rationnel& f1, int& m);
     friend Rationnel operator/(Rationnel& f1, int& m);
     friend Rationnel operator-(Rationnel& f1, int& m);

private:
    int m_numerateur;
    unsigned int m_denominateur;
    int m;
};

class Rationnel_Normalise : public Rationnel
{
public:
   void rationnelNormalise(int &a,int &b);
private:
    int m_numerateur;
    unsigned int m_denominateur;
    int m;
};

// FONCTIONS UTILISEES

void rationnel(int &a);
void rationnelNormalise(int &a,int &b);
int pgcd(int x,int y);
void Affichage_TABLE(int n,int z);
void Inverse();
void Normalisation();
void Somme_Produit(int Somme[],int Produit[]);
void afficher();
void Comparer(int a1, int b1, int a2, int b2);
void Classement (int n);













#endif // CLASS_H
