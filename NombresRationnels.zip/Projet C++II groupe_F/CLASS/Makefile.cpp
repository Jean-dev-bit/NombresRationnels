#include"CLASS.h"
#include<iostream>
#include<iomanip>
using namespace std;

// VERIFICATION D'UN NOMBRE RATIONEL
    void rationnel(int &a){
        while(a==0){
            cout<<"VEUILLEZ SAISIR UN  DENOMINATEUR DIFFERENT DE ZERO : ";
            cin>>a;
        }
    }

// PGCD
    int pgcd(int x,int y){
        while(x != y)
        {
        if(x>y)
        x-=y;
        else
        y -= x;
        }
        return x;
    }

// VERIFICATION D'UN NOMBRE RATIONNEL NORMALISE
void rationnelNormalise(int &a,int &b){
    while(b<=0 || pgcd(a,b)!=1){
        cout<<"VOULANT UN  NOMBRE RATIONNEL NORMALISE, LE DENOMINATEUR DOIT ETRE DIFFERENT DE 0 ET LE PGCD DES NOMBRES SAISIS DOIT ETRE EGAL A 1. \n"<<endl;
        cout<<"VEUILLEZ ENTRER DE NOUVEAUX NOMBRES "<<endl;
        cout<<endl;
        cout<<"ENTRER LE  NUMERATEUR : ";
        cin>>a;
        cout<<endl;
        cout<<"ENTRER LE DENOMINATEUR : ";
        cin>>b;
        cout<<endl;
    }
}

//AFFICHAGE SOUS FORME TABLEAU

void Affichage_TABLE(int n,int z){
    cout<<"["<<n<<","<<z<<"]"<<endl;
}

// Addition de deux nombres rationnels

Rationnel operator+(Rationnel& f1, Rationnel& f2) {
//Opération des dénominateurs
    int produit_denominateur = f1.m_denominateur * f2.m_denominateur;
    int numerateur = f1.m_numerateur * f2.m_denominateur + f2.m_numerateur * f1.m_denominateur;
    return Rationnel(numerateur, produit_denominateur);
}

// Soustraction de  deux nombres rationnels

Rationnel operator-(Rationnel& f1, Rationnel& f2) {
    int produit_denominateur = f1.m_denominateur * f2.m_denominateur;
    int numerateur = f1.m_numerateur * f2.m_denominateur - f2.m_numerateur * f1.m_denominateur;
    return Rationnel(numerateur, produit_denominateur);
}

// Multiplications de deux nombres rationnels

Rationnel operator*(Rationnel& f1, Rationnel& f2) {
    int numerateur = f1.m_numerateur * f2.m_numerateur;
    int denominateur = f1.m_denominateur * f2.m_denominateur;
    return Rationnel(numerateur, denominateur);
}


// Division de deux nombres  rationnels

Rationnel operator/(Rationnel& f1, Rationnel& f2) {
    int numerateur = f1.m_numerateur * f2.m_denominateur;
    int denominateur = f1.m_denominateur * f2.m_numerateur;
    return Rationnel(numerateur, denominateur);
}

// Opération entre rationnel et un entier

// Addition de d'un nombre rationnel avec le premier tableau f1 et un entier

Rationnel operator+(Rationnel& f1, int& m) {
    //Opération des dénominateurs
    int produit_denominateur = f1.m_denominateur *1;
    int numerateur = f1.m_numerateur *1 + m * f1.m_denominateur;
    return Rationnel(numerateur, produit_denominateur);
}


// Multiplication d'un nombre rationnel le premier tableau f1  et un entier

Rationnel operator*(Rationnel& f1, int& m) {
    int numerateur = f1.m_numerateur * m;
    int denominateur = f1.m_denominateur*1;
    return Rationnel(numerateur, denominateur);
}

// Division d'un rationnel et un entier

Rationnel operator/(Rationnel& f1, int& m) {
    int numerateur = f1.m_numerateur * 1;
    int denominateur = f1.m_denominateur * m;
    return Rationnel(numerateur, denominateur);
}

// Soustraction d'un rationnel et un entier

Rationnel operator-(Rationnel& f1, int& m) {
    int produit_denominateur = f1.m_denominateur * 1;
    int numerateur = f1.m_numerateur * 1 - m * f1.m_denominateur;
    return Rationnel(numerateur, produit_denominateur);
}
// Inverse d'une fraction
void Inverse(){
    int num,denom;
    std::cout<<"ENTRER LE NUMERATEUR : ";
    std::cin>>num;
    cout<<endl;
    std::cout<<"ENTRER LE DENOMINATEUR : ";
    std::cin>>denom;
    cout<<endl;
    rationnel(denom);
    cout<<endl;
    int numerateur = denom;
    int denominateur = num;
    std::cout<<"L'INVERSE DE "<<num<<"/"<<denom<<" : "<<numerateur<<"/"<<denominateur<<std::endl;
}

//NORMALISATION

void Normalisation(){
    int num,denom;
    std::cout<<"ENTRER LE NUMERATEUR : ";
    std::cin>>num;
    cout<<endl;
    std::cout<<"ENTRER LE DENOMINATEUR : ";
    std::cin>>denom;
    cout<<endl;
    rationnel(denom);
    cout<<endl;
    int  m = pgcd(num,denom);
    int y = num/m;
    int lcd = denom/m;
    std::cout<<"LA NORMALISATION DE  "<<num<<"/"<<denom<<" EST : "<<y<<"/"<<lcd<<std::endl;
}

//SOMME & PRODUIT DES N RATIONNELS

void Somme_Produit(int Somme[],int Produit[]){
    int taille;
    std::cout<<" ENTRER LE NOMBRE DE NOMBRES RATIONNELS : ";
    cin>>taille;
    std::cout<<std::endl;
    int f1[taille],f2[taille];
    for(int i=0;i<taille;i++){
        std::cout<<" ENTRER LE NUMERATEUR : ";
        std::cin>>f1[i];
        std::cout<<std::endl;
        std::cout<<" ENTRER LE DENOMINATEUR : ";
        std::cin>>f2[i];
        std::cout<<std::endl;
        rationnel(f2[i]);
        std::cout<<std::endl;
        std::cout<<" FRACTION : ";
        Affichage_TABLE(f1[i],f2[i]);
        std::cout<<std::endl;
        std::cout<<std::endl;


    }
    //SOMME DE N RATIONNELS
    Somme[0] = f1[0];
    Somme[1] = f2[0];

    for(int i=1;i<taille;i++){
       Somme[0] = Somme[0]*f2[i] + Somme[1]*f1[i];
      Somme[1] = Somme[1]*f2[i];
   }
    int num1 = Somme[0];
    int denom1 = Somme[1];
    std::cout<<" LA SOMME DE N RATIONNELS EST : ";
    Affichage_TABLE(num1,denom1);
// PRODUITS DE N RATIONNELS
    Produit[0] = f1[0];
    Produit[1] = f2[0];
    for(int i=1;i<taille;i++){
        Produit[0] = Produit[0]*f1[i];
        Produit[1] = Produit[1]*f2[i];
    }

    int num = Produit[0];
    int denom = Produit[1];
    cout<<endl;
    std::cout<<" LE PRODUIT DE N RATIONNELS EST : ";
    Affichage_TABLE(num,denom);
}
// AFFICHAGE DES NOMBRES

void afficher(){
    int f1,f2;
    std::cout<<" ENTRER LE NUMERATEUR : ";
    std::cin>>f1;
    std::cout<<std::endl;
    std::cout<<" ENTRER LE DENOMINATEUR : ";
    std::cin>>f2;
    std::cout<<std::endl;
    rationnel(f2);
    cout<<endl;
    std::cout<<"L'affichage d'un nombre rationnel sous le format num / den :  "<<f1<<"/"<<f2<<std::endl;
    std::cout<<std::endl;


}

//COMPARAISON

void Comparer(int a1, int b1, int a2, int b2){
    double r1=double(a1)/b1;
    rationnel(b1);
    cout<<endl;
    double r2=double(a2)/b2;
    cout<<endl;
    rationnel(b2);
    if (r1<r2){
        cout<<" 1 "<<endl;
    }else{
        cout<<" 0 ";
    }
}

//CLASSEMENT
void Classement (int n){
    double T[n];
    double k;
    int m;
      for (int i=0; i<n; i++){
          std::cout<<std::endl;
          cout<<"ENTRER LE NUMERATEUR DE  "<<i+1<<" NOMBRE RATIONNEL : ";
          cin>>k;
          std::cout<<std::endl;
          cout<<"ENTRER LE DENOMINATEUR DE "<<i+1<<" NOMBRE  RATIONNEL : ";
          cin>>m;
          cout<<endl;
          rationnel(m);
          T[i] = (k/m);
          std::cout<<std::endl;
}
            for (int i=0;i<n; i++){

                for (int j=(i+1);j<n;j++){

                          if (T[j]<T[i]){
                              double temp = T[i];
                                 T[i] = T[j];
                                  T[j] = temp;}
        }
    }
    cout<<endl<<"------VOICI  EN  ODRE CROISSANT LES NOMBRES QUE VOUS AVEZ SAISIS-----"<<endl;
     for (int i=0;i<n; i++){
           cout<<"\t"<<T[i];

    }
}

