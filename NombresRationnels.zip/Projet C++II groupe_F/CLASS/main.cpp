#include <QCoreApplication>
#include<iostream>
#include<iomanip>
#include"CLASS.h"
#include<string.h>
using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    cout<<endl;
    cout<<"----------------------Bienvenu dans notre Programme---------------------------"<<endl;
    cout<<endl;
    cout<<"----Operations sur les rationnels representes par des tableaux----"<<endl;
    cout<<endl;
    cout<<endl;
    cout<<"1. Addition de deux rationnels qui donne un rationnel. "<<endl;
    cout<<"2. Addition d'un rationnel et d'un entier qui donne un rationnel. "<<endl;
    cout<<"3. Addition de deux rationnels normalises qui donnent un rationnel normalise. "<<endl;
    cout<<"4. Multiplication de deux rationnels qui donne un rationnel. "<<endl;
    cout<<"5. Multiplication d'un rationnel et d'un entier qui donne un rationnel. "<<endl;
    cout<<"6. Multiplication de deux rationnels normalises qui donne un rationnel normalise. "<<endl;
    cout<<"7. Division de deux rationnels qui donne un rationnel (si la division est possible). "<<endl;
    cout<<"8. Division d'un rationnel et d'un entier qui donne un rationnel (si possible). "<<endl;
    cout<<"9. Division de deux rationnels normalises qui donne un rationnel normalise (si possible). "<<endl;
    cout<<"10.Soustraction de deux rationnels qui donne un rationnel. "<<endl;
    cout<<"11.Soustraction d'un rationnel et d'un entier qui donne un rationnel. "<<endl;
    cout<<"12.Soustraction de deux rationnels normalises qui donne un rationnel normalise. "<<endl;
    cout<<"13.L'inverse d'un rationnel qui donne un rationnel (si l'operation est possible). "<<endl;
    cout<<"14.La normalisation d'un rationnel qui donne le rationnel normalise correspondant. "<<endl;
    cout<<"15.La somme et le produit de n nombres rationnels qui donne un rationnel. "<<endl;
    cout<<"16.L'affichage d'un nombre rationnel sous le format num / den."<<endl;
    cout<<"17.La relation d'ordre sur les rationnels, qui compare deux rationnels r1 et r2 et donne 1 si r1 est plus petit que r2, sinon donne 0. "<<endl;
    cout<<"18.Le classement des representants reels de n nombres rationnels.  "<<endl;
    cout<<endl;

    string choix_second;
do{
 int choix;
    cout<<" ENTRER LE CHOIX DE L'OPERATION VOULUE : ";
    cin>>choix;
    cout<<endl;
    if(choix==1){
        cout<<"----VALEURS DES TABLEAUX----"<<endl;
        int num1,denom1,num2,denom2;
        cout<<endl;
        cout<<" PREMIERE FRACTION "<<endl;
        cout<<endl;
        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
        cin>>num1;
        cout<<endl;
        cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
        cin>>denom1;
        cout<<endl;
        rationnel(denom1);
        cout<<endl;
        Rationnel f1(num1,denom1);
        cout<<endl;
        cout<<" DEUXIEME FRACTION "<<endl;
        cout<<endl;
        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
        cin>>num2;
        cout<<endl;
        cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
        cin>>denom2;
        cout<<endl;
        rationnel(denom2);
        Rationnel f2(num2,denom2);
        Rationnel sum = (f1 + f2);
        cout<<endl;
        cout<<endl;
        cout << "L'Addition de deux rationnels qui donne un rationnel : ";
        Affichage_TABLE(sum.getNumerator(),sum.getDenominator());
        cout<<endl;
    }else{
        if(choix==2){
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            int num1,denom1;
            cout<<endl;
            cout<<" PREMIERE FRACTION "<<endl;
            cout<<endl;
            cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
            cin>>num1;
            cout<<endl;
            cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
            cin>>denom1;
            cout<<endl;
            rationnel(denom1);
            Rationnel f1(num1,denom1);
            cout<<endl;
            int m;
           cout<<" ENTRER L'ENTIER DE VOTRE CHOIX : ";
           cin>>m;
           Rationnel sum_rationnel_entier = (f1 + m);
           cout<<endl;
           cout <<"L'Addition d'un rationnel et d'un entier qui donne un rationnel : ";
           Affichage_TABLE(sum_rationnel_entier.getNumerator(),sum_rationnel_entier.getDenominator());
           cout<<endl;
        }else{
            if(choix==3){
                cout<<"----VALEURS DES TABLEAUX----"<<endl;
                int num1,denom1,num2,denom2;
                cout<<endl;
                cout<<" PREMIERE FRACTION "<<endl;
                cout<<endl;
                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                cin>>num1;
                cout<<endl;
                cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                cin>>denom1;
                cout<<endl;
                rationnelNormalise(num1,denom1);
                Rationnel f1(num1,denom1);
                cout<<endl;
                cout<<" DEUXIEME FRACTION "<<endl;
                cout<<endl;
                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                cin>>num2;
                cout<<endl;
                cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                cin>>denom2;
                cout<<endl;
                rationnelNormalise(num2,denom2);
                Rationnel f2(num2,denom2);
                Rationnel sum_Normalise = (f1 + f2);
                cout<<endl;
                cout<<endl;
                cout << "L'Addition de deux rationnels normalises qui donnent un rationnel normalise : ";
                Affichage_TABLE(sum_Normalise.getNumerator(),sum_Normalise.getDenominator());
                cout<<endl;
            }else{
                if(choix==4){
                cout<<"----VALEURS DES TABLEAUX----"<<endl;
                int num1,denom1,num2,denom2;
                cout<<endl;
                cout<<" PREMIERE FRACTION "<<endl;
                cout<<endl;
                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                cin>>num1;
                cout<<endl;
                cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                cin>>denom1;
                cout<<endl;
                rationnel(denom1);
                Rationnel f1(num1,denom1);
                cout<<endl;
                cout<<" DEUXIEME FRACTION "<<endl;
                cout<<endl;
                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                cin>>num2;
                cout<<endl;
                cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                cin>>denom2;
                cout<<endl;
                rationnel(denom2);
                Rationnel f2(num2,denom2);
                Rationnel multiplication = (f1 * f2);
                cout<<endl;
                cout << "La Multiplication de deux rationnels qui donne un rationnel : ";
                Affichage_TABLE(multiplication.getNumerator(),multiplication.getDenominator());
                cout<<endl;
                }else{
                    if(choix==5){
                        cout<<"----VALEURS DES TABLEAUX----"<<endl;
                        int num1,denom1;
                        cout<<endl;
                        cout<<" PREMIERE FRACTION "<<endl;
                        cout<<endl;
                        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                        cin>>num1;
                        cout<<endl;
                        cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                        cin>>denom1;
                        cout<<endl;
                        rationnel(denom1);
                        cout<<endl;
                        Rationnel f1(num1,denom1);
                        int m;
                        cout<<" ENTRER L'ENTIER DE VOTRE CHOIX : ";
                        cin>>m;
                        Rationnel multiplication_rationnel_entier = (f1 * m);
                        cout<<endl;
                        cout <<"La Multiplication d'un rationnel et d'un entier qui donne un rationnel : ";
                        Affichage_TABLE(multiplication_rationnel_entier.getNumerator(),multiplication_rationnel_entier.getDenominator());
                        cout<<endl;
                    }else{
                        if(choix==6){
                            cout<<"----VALEURS DES TABLEAUX----"<<endl;
                            int num1,denom1,num2,denom2;
                            cout<<endl;
                            cout<<" PREMIERE FRACTION "<<endl;
                            cout<<endl;
                            cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                            cin>>num1;
                            cout<<endl;
                            cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                            cin>>denom1;
                            cout<<endl;
                            rationnelNormalise(num1,denom1);
                            cout<<endl;
                            Rationnel f1(num1,denom1);
                            cout<<endl;
                            cout<<" DEUXIEME FRACTION "<<endl;
                            cout<<endl;
                            cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                            cin>>num2;
                            cout<<endl;
                            cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                            cin>>denom2;
                            cout<<endl;
                            rationnelNormalise(num2,denom2);
                            cout<<endl;
                            Rationnel f2(num2,denom2);
                            Rationnel multiplication_Normalise = (f1 * f2);
                            cout << "La Multiplication de deux rationnels normalises qui donne un rationnel normalise : ";
                            Affichage_TABLE(multiplication_Normalise.getNumerator(),multiplication_Normalise.getDenominator());
                            cout<<endl;
                        }else{
                            if(choix==7){
                                cout<<"----VALEURS DES TABLEAUX----"<<endl;
                                int num1,denom1,num2,denom2;
                                cout<<endl;
                                cout<<" PREMIERE FRACTION "<<endl;
                                cout<<endl;
                                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                cin>>num1;
                                cout<<endl;
                                cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                                cin>>denom1;
                                cout<<endl;
                                rationnel(denom1);
                                Rationnel f1(num1,denom1);
                                cout<<endl;
                                cout<<" DEUXIEME FRACTION "<<endl;
                                cout<<endl;
                                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                cin>>num2;
                                cout<<endl;
                                cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                cin>>denom2;
                                cout<<endl;
                                rationnel(denom2);
                                cout<<endl;
                                Rationnel f2(num2,denom2);
                                Rationnel division = (f1 / f2);
                                cout << "La Division de deux rationnels qui donne un rationnel (si la division est possible): ";
                                Affichage_TABLE(division.getNumerator(),division.getDenominator());
                                cout<<endl;
                            }else{
                                if(choix==8){
                                    cout<<"----VALEURS DES TABLEAUX----"<<endl;
                                    int num1,denom1;
                                    cout<<endl;
                                    cout<<" PREMIERE FRACTION "<<endl;
                                    cout<<endl;
                                    cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                    cin>>num1;
                                    cout<<endl;
                                    cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                    cin>>denom1;
                                    cout<<endl;
                                    rationnel(denom1);
                                    Rationnel f1(num1,denom1);
                                    cout<<endl;
                                    int m;
                                    cout<<" ENTRER L'ENTIER DE VOTRE CHOIX : ";
                                    cin>>m;
                                    cout<<endl;
                                    Rationnel division_rationnel_entier = (f1 / m);
                                    cout<<"Division d'un rationnel et d'un entier qui donne un rationnel (si possible) : ";
                                    Affichage_TABLE(division_rationnel_entier.getNumerator(),division_rationnel_entier.getDenominator());
                                    cout<<endl;
                                }else{
                                    if(choix==9){
                                        cout<<"----VALEURS DES TABLEAUX----"<<endl;
                                        int num1,denom1,num2,denom2;
                                        cout<<endl;
                                        cout<<" PREMIERE FRACTION "<<endl;
                                        cout<<endl;
                                        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                        cin>>num1;
                                        cout<<endl;
                                        cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                                        cin>>denom1;
                                        cout<<endl;
                                        rationnelNormalise(num1,denom1);
                                        cout<<endl;
                                        Rationnel f1(num1,denom1);
                                        cout<<endl;
                                        cout<<" DEUXIEME FRACTION "<<endl;
                                        cout<<endl;
                                        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                        cin>>num2;
                                        cout<<endl;
                                        cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                        cin>>denom2;
                                        cout<<endl;
                                        rationnelNormalise(num2,denom2);
                                        cout<<endl;
                                        Rationnel f2(num2,denom2);
                                        Rationnel division_Normalise = (f1 / f2);
                                        cout << "La Division de deux rationnels normalises qui donne un rationnel normalise (si possible): ";
                                        Affichage_TABLE(division_Normalise.getNumerator(),division_Normalise.getDenominator());
                                        cout<<endl;
                                    }else{
                                        if(choix==10){
                                            cout<<"----VALEURS DES TABLEAUX----"<<endl;
                                            int num1,denom1,num2,denom2;
                                            cout<<endl;
                                            cout<<" PREMIERE FRACTION "<<endl;
                                            cout<<endl;
                                            cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                            cin>>num1;
                                            cout<<endl;
                                            cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                                            cin>>denom1;
                                            cout<<endl;
                                            rationnel(denom1);
                                            Rationnel f1(num1,denom1);
                                            cout<<endl;
                                            cout<<" DEUXIEME FRACTION "<<endl;
                                            cout<<endl;
                                            cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                            cin>>num2;
                                            cout<<endl;
                                            cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                            cin>>denom2;
                                            cout<<endl;
                                            rationnel(denom2);
                                            cout<<endl;
                                            Rationnel f2(num2,denom2);
                                            Rationnel soustraction = (f1 - f2);
                                            cout << "La Soustraction de deux rationnels qui donne un rationnel: ";
                                            Affichage_TABLE(soustraction.getNumerator(),soustraction.getDenominator());
                                            cout<<endl;
                                        }else{
                                            if(choix==11){
                                                int num1,denom1;
                                                cout<<endl;
                                                cout<<" PREMIERE FRACTION "<<endl;
                                                cout<<endl;
                                                cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                                cin>>num1;
                                                cout<<endl;
                                                cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                                cin>>denom1;
                                                cout<<endl;
                                                rationnel(denom1);
                                                Rationnel f1(num1,denom1);
                                                cout<<endl;
                                                int m;
                                                cout<<" ENTRER L'ENTIER DE VOTRE CHOIX : ";
                                                cin>>m;
                                                Rationnel soustraction_rationnel_entier = (f1 - m);
                                                cout<<endl;
                                                cout << "La Soustraction d'un rationnel et d'un entier qui donne un rationnel: ";
                                                Affichage_TABLE(soustraction_rationnel_entier.getNumerator(),soustraction_rationnel_entier.getDenominator());
                                                cout<<endl;
                                            }else{
                                                if(choix==12){
                                                    cout<<"----VALEURS DES TABLEAUX----"<<endl;
                                                    int num1,denom1,num2,denom2;
                                                    cout<<endl;
                                                    cout<<" PREMIERE FRACTION "<<endl;
                                                    cout<<endl;
                                                    cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                                    cin>>num1;
                                                    cout<<endl;
                                                    cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                                                    cin>>denom1;
                                                    cout<<endl;
                                                    rationnelNormalise(num1,denom1);
                                                    cout<<endl;
                                                    Rationnel f1(num1,denom1);
                                                    cout<<endl;
                                                    cout<<" DEUXIEME FRACTION "<<endl;
                                                    cout<<endl;
                                                    cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                                    cin>>num2;
                                                    cout<<endl;
                                                    cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                                    cin>>denom2;
                                                    cout<<endl;
                                                    rationnelNormalise(num2,denom2);
                                                    cout<<endl;
                                                    Rationnel f2(num2,denom2);
                                                    Rationnel soustraction_Normalise = (f1 - f2);
                                                    cout << "La Soustraction de deux rationnels normalises qui donne un rationnel normalise: ";
                                                    Affichage_TABLE(soustraction_Normalise.getNumerator(),soustraction_Normalise.getDenominator());
                                                    cout<<endl;
                                                }else{
                                                    if(choix==13){
                                                         Inverse();
                                                    }else{
                                                        if(choix==14){
                                                             Normalisation();
                                                        }else{
                                                            if(choix==15){
                                                                int tab[2];
                                                                int table[2];
                                                                Somme_Produit(tab,table);
                                                            }else{
                                                                if(choix==16){
                                                                           afficher();
                                                                }else{
                                                                    if(choix==17){
                                                                        int num1,denom1,num2,denom2;
                                                                        cout<<endl;
                                                                        cout<<" PREMIERE FRACTION "<<endl;
                                                                        cout<<endl;
                                                                        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                                                        cin>>num1;
                                                                        cout<<" ENTRER LE DENOMINATEUR: "<<setw(2);
                                                                        cin>>denom1;
                                                                        rationnel(denom1);
                                                                        cout<<endl;
                                                                        cout<<" DEUXIEME FRACTION "<<endl;
                                                                        cout<<endl;
                                                                        cout<<" ENTRER LE NUMERATEUR : "<<setw(2);
                                                                        cin>>num2;
                                                                        cout<<" ENTRER LE DENOMINATEUR : "<<setw(2);
                                                                        cin>>denom2;
                                                                        rationnel(denom2);
                                                                        Comparer(num1,denom1,num2,denom2);
                                                                    }else{
                                                                        if(choix==18){
                                                                            int taille;
                                                                            std::cout<<" ENTRER LE NOMBRE DE NOMBRES RATIONNELS : ";
                                                                            cin>>taille;
                                                                            Classement(taille);
                                                                        }else{
                                                                            cout<<" VOTRE CHOIX EST MAUVAIX ! RESSAYER "<<endl;
                                                                            cout<<endl;

                                                                           }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    cout<<endl;
    cout<<" VOULEZ - VOUS REPRENDRE OUI ou NON ?  "<<endl;
    cout<<endl;
    cin>>choix_second;
    cout<<endl;
    }while (choix_second=="OUI" || choix_second=="Oui" || choix_second=="oui");

    cout<<" FIN DE PROGRAMME ! "<<endl;




    return a.exec();
}
