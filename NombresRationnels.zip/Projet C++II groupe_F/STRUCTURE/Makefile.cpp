#include"STRUCTURE.h"
#include<iostream>
using namespace std;

//Vérificattion d'un nombre rationnel

    void rationnel(int &a){
        while(a==0){
            cout<<"Veuillez entrer un denominateur different de zero : ";
            cin>>a;
        }
    }

    //Plus grand commun Diviseur

    int pgcd(int x,int y){
        while(x != y)
        {
        if(x>y)
        x-=y;
        else
        y -= x;
        }
        return x;
    }

    // Vérification d'un nombre rationnel normalisé

    void rationnelNormalise(int &a,int &b){
        while(b<=0 || pgcd(a,b)!=1){
         cout<<"----MESSAGE D'ALERTE----"<<endl;
         cout<<" Voulant un  nombre rationnel normalise,le denominateur doit etre different de 0 \n et le PGCD des nombres saisis doit etre egal a 1. \n"<<" Veuillez entrer de nouveaux nombres "<<endl;
         cout<<endl;
         cout<<"Entrer le nouveau numerateur : ";
         cin>>a;
         cout<<"Entrer le nouveau denominateur : ";
         cin>>b;
    }
    }

    // Fonction qui demande à l'utilisateur les nombres rationnels Normalisés

    int demandeRationnel_Normalise (int &numr, int &denr){
        cout<<endl;
        cout<<"Entrer le numerateur du nombre rationnel normalise : ";
        cin>>numr;
        cout<<"Entrer le denominateur du nombre rationnel normalise : ";
        cin>>denr;
        cout<<endl;
        rationnelNormalise(numr, denr);
        return numr,denr;
    }

// Affichage des nombres

    void Affichage_Nombre (int a, int b){
        cout<<"["<<a<<","<<b<<"]";
    }

    // Fonction pour additionner deux rationnels

        Rationnel addition(Rationnel r1, Rationnel r2) {
          Rationnel res;
          res.num = r1.num * r2.den + r2.num * r1.den;
          res.den = r1.den * r2.den;
          Affichage_Nombre(res.num,res.den);
          return res;
    }
        // Fonction pour ajouter un entier à un rationnel

            Rationnel addition(Rationnel r, int entier) {
              Rationnel entierRationnel = {entier, 1};
              return addition(r, entierRationnel);
            }


    //Nombres normalisés

  Rationnel addition_Normalise(Rationnel r1, Rationnel r2) {
      Rationnel res;
      res.num = r1.num * r2.den + r2.num * r1.den;
      res.den = r1.den * r2.den;
      Affichage_Nombre(res.num,res.den);
      return res;
}
  // Fonction pour multiplier deux rationnels

      Rationnel multiplication(Rationnel r1, Rationnel r2) {
        Rationnel res;
        res.num = r1.num * r2.num;
        res.den = r1.den * r2.den;
        Affichage_Nombre(res.num,res.den);
        return res;
      }


      // Fonction pour multiplier un rationnel par un entier

          Rationnel multiplication(Rationnel r, int entier) {
            Rationnel entierRationnel = {entier, 1};
            return multiplication(r, entierRationnel);
          }
           //Nombres normalisés

          Rationnel Multiplication_Normalise(Rationnel r1, Rationnel r2) {
              Rationnel res;
              res.num = r1.num * r2.num;
              res.den = r1.den * r2.den;
              Affichage_Nombre(res.num,res.den);
              return res;
        }
          // Fonction pour diviser deux rationnels

              Rationnel Division(Rationnel r1, Rationnel r2) {
                Rationnel res;
                res.num = r1.num * r2.den;
                res.den = r1.den * r2.num;
                Affichage_Nombre(res.num,res.den);
                return res;
              }

              // Fonction pour diviser un rationnel par un entier

                  Rationnel Division(Rationnel r, int entier) {
                    Rationnel entierRationnel = {entier, 1};
                    return Division(r, entierRationnel);
                  }
                  // Division Normalisés

                  Rationnel Division_Normalise(Rationnel r1, Rationnel r2) {
                    Rationnel res;
                    res.num = r1.num * r2.den;
                    res.den = r1.den * r2.num;
                    Affichage_Nombre(res.num,res.den);
                    return res;
                  }
                  // Fonction pour soustraire deux rationnels

                      Rationnel soustraire(Rationnel r1, Rationnel r2) {
                        Rationnel res;
                        res.num = r1.num * r2.den - r2.num * r1.den;
                        res.den = r1.den * r2.den;
                        Affichage_Nombre(res.num,res.den);
                        return res;
                  }
                      // Fonction pour soustraire un entier à un rationnel

                          Rationnel soustraire(Rationnel r, int entier) {
                            Rationnel entierRationnel = {entier, 1};
                            return soustraire(r, entierRationnel);
                          }

                          //Nombres normalisés

                        Rationnel soustraire_Normalise(Rationnel r1, Rationnel r2) {
                            Rationnel res;
                            res.num = r1.num * r2.den - r2.num * r1.den;
                            res.den = r1.den * r2.den;
                            Affichage_Nombre(res.num,res.den);
                            return res;
                      }

                        // Fonction pour inverser un rationnel

                            Rationnel inverse(Rationnel r) {
                              Rationnel res;
                              res.num = r.den;
                              res.den = r.num;
                              Affichage_Nombre(res.num,res.den);
                              return res;
                            }

                            //Normalisation

                                Rationnel Normalisation(Rationnel r1){
                                int num = r1.num/pgcd(r1.num,r1.den);
                                int den = r1.den/pgcd(r1.num,r1.den);
                                Affichage_Nombre(num,den);
                               }

                                //SOMME & PRODUIT DES N RATIONNELS

                                void Somme_Produit(int Somme[],int Produit[]){
                                    int taille;
                                    std::cout<<" Entrer le nombre de nombre rationnels que vous voulez saisis : ";
                                    cin>>taille;
                                    std::cout<<std::endl;
                                    int f1[taille],f2[taille];
                                    for(int i=0;i<taille;i++){
                                        std::cout<<" Entrer la numerateur : ";
                                        std::cin>>f1[i];
                                        std::cout<<std::endl;
                                        std::cout<<" Entrer le denominateur : ";
                                        std::cin>>f2[i];
                                        std::cout<<std::endl;
                                        rationnel(f2[i]);
                                        std::cout<<std::endl;
                                        std::cout<<" Fraction : ";
                                        Affichage_Nombre(f1[i],f2[i]);
                                        std::cout<<std::endl;


                                    }
                                    //SOMME DE N RATIONNELS
                                    Somme[0] = f1[0];
                                    Somme[1] = f2[0];

                                    for(int i=1;i<taille;i++){
                                       Somme[0] = Somme[0]*f2[i] + Somme[1]*f1[i];
                                      Somme[1] = Somme[1]*f2[i];
                                   }
                                    int num1 = Somme[0];
                                    int denom1 = Somme[1];
                                    std::cout<<" La somme de n rationnels : ";
                                    Affichage_Nombre(num1,denom1);
                                // PRODUITS DE N RATIONNELS
                                    Produit[0] = f1[0];
                                    Produit[1] = f2[0];
                                    for(int i=1;i<taille;i++){
                                        Produit[0] = Produit[0]*f1[i];
                                        Produit[1] = Produit[1]*f2[i];
                                    }

                                    int num = Produit[0];
                                    int denom = Produit[1];
                                    cout<<endl;
                                    std::cout<<"Le produit de n rationnels : ";
                                    Affichage_Nombre(num,denom);
                                }

                                // Fonction pour afficher un rationnel sous la forme num/den
                                      void afficher(Rationnel r) {
                                        cout << r.num << "/" << r.den << endl;
                                      }

                                      //Comparaison
                                      Rationnel Comparer(Rationnel r1, Rationnel r2){
                                          double p,q;
                                          p = double(r1.num)/double(r1.den);
                                          rationnel(r1.den);
                                          cout<<endl;
                                          q = double(r2.num)/double(r2.den);
                                          cout<<endl;
                                          rationnel(r2.den);
                                          if (p<q){
                                              cout<<" 1 "<<endl;
                                          }else{
                                              cout<<" 0 ";
                                          }
                                      }



                                      //CLASSEMENT
                                      Rationnel Classement (int n){
                                          double T[n];
                                          Rationnel k;
                                            for (int i=0; i<n; i++){
                                                cout<<"Entrer le numerateur de "<<i+1<<" nombre rationnel : ";
                                                cin>>k.num;
                                                cout<<"Entrer le denominateur de "<<i+1<<" nombre rationnel : ";
                                                cin>>k.den;
                                                rationnel(k.den);
                                                T[i] = double(k.num)/double(k.den);
                                      }
                                                  for (int i=0;i<n; i++){

                                                      for (int j=(i+1);j<n;j++){

                                                                if (T[j]<T[i]){
                                                                    double temp = T[i];
                                                                       T[i] = T[j];
                                                                        T[j] = temp;}
                                              }
                                          }
                                          cout<<endl<<"------VOICI  EN  ODRE CROISSANT LES NOMBRES QUE VOUS AVEZ SAISIS-----"<<endl;
                                          cout<<endl;
                                          for (int i=0;i<n; i++){
                                                 cout<<"\t"<<T[i];

                                          }
                                      }

