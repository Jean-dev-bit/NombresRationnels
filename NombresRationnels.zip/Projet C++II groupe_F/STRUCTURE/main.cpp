#include <QCoreApplication>
#include"STRUCTURE.h"
#include<iostream>
#include<iomanip>
#include"string.h"
using namespace std;

int main(int argc, char *argv[])

{
    QCoreApplication a(argc, argv);
    cout<<endl;
       cout<<"----------------------Bienvenu dans notre Programme---------------------------"<<endl;
       cout<<endl;
       cout<<"----Operations sur les rationnels representes par des tableaux----"<<endl;
       cout<<endl;
       cout<<endl;
       cout<<"1. Addition de deux rationnels qui donne un rationnel. "<<endl;
       cout<<"2. Addition d'un rationnel et d'un entier qui donne un rationnel. "<<endl;
       cout<<"3. Addition de deux rationnels normalises qui donnent un rationnel normalise. "<<endl;
       cout<<"4. Multiplication de deux rationnels qui donne un rationnel. "<<endl;
       cout<<"5. Multiplication d'un rationnel et d'un entier qui donne un rationnel. "<<endl;
       cout<<"6. Multiplication de deux rationnels normalises qui donne un rationnel normalise. "<<endl;
       cout<<"7. Division de deux rationnels qui donne un rationnel (si la division est possible). "<<endl;
       cout<<"8. Division d'un rationnel et d'un entier qui donne un rationnel (si possible). "<<endl;
       cout<<"9. Division de deux rationnels normalises qui donne un rationnel normalise (si possible). "<<endl;
       cout<<"10.Soustraction de deux rationnels qui donne un rationnel. "<<endl;
       cout<<"11.Soustraction d'un rationnel et d'un entier qui donne un rationnel. "<<endl;
       cout<<"12.Soustraction de deux rationnels normalises qui donne un rationnel normalise. "<<endl;
       cout<<"13.L'inverse d'un rationnel qui donne un rationnel (si l'operation est possible). "<<endl;
       cout<<"14.La normalisation d'un rationnel qui donne le rationnel normalise correspondant. "<<endl;
       cout<<"15.La somme et le produit de n nombres rationnels qui donne un rationnel. "<<endl;
       cout<<"16.L'affichage d'un nombre rationnel sous le format num / den."<<endl;
       cout<<"17.La relation d'ordre sur les rationnels, qui compare deux rationnels r1 et r2 et donne 1 si r1 est plus petit que r2, sinon donne 0. "<<endl;
       cout<<"18.Le classement des representants reels de n nombres rationnels.  "<<endl;
       cout<<endl;
        Rationnel m;
        cout<<endl;
        string second_choix;
        do{
                 int choix;
                cout<<"Entrer le choix voulu : ";
                cin>>choix;
                Rationnel n,n1;


        switch (choix) {

        case 1:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n.num;
            cout<<" Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n1.num;
            cout<<" Entrer le denominateur : ";
            cin>>n1.den;
            cout<<endl;
            rationnel(n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Addition de deux rationnels qui donne un rationnel : ";
            addition(n,n1);
            break;
        case 2:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<endl;
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<"Entrer l'entier : ";
            cin>>m.entier;
            cout<<endl;
            cout<<endl;
            cout<<" Addition d'un rationnel et d'un entier qui donne un rationnel : ";
            addition(n,m.entier);
            break;
        case 3:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            demandeRationnel_Normalise(n.num,n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            demandeRationnel_Normalise(n1.num,n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Addition de deux rationnels normalises qui donnent un rationnel normalise : ";
            addition_Normalise(n,n1);
            break;
       case 4:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n.num;
            cout<<" Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n1.num;
            cout<<" Entrer le denominateur : ";
            cin>>n1.den;
            cout<<endl;
            rationnel(n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Multiplication de deux rationnels qui donne un rationnel : ";
            multiplication(n,n1);
            break;
        case 5:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<endl;
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<"Entrer l'entier : ";
            cin>>m.entier;
            cout<<endl;
            cout<<endl;
            cout<<" Multiplication d'un rationnel et d'un entier qui donne un rationnel : ";
            multiplication(n,m.entier);
             break;
        case 6:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            demandeRationnel_Normalise(n.num,n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            demandeRationnel_Normalise(n1.num,n1.den);
            cout<<endl;
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Multiplication de deux rationnels normalises qui donne un rationnel normalise : ";
            Multiplication_Normalise(n,n1);
             break;
        case 7:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n.num;
            cout<<" Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n1.num;
            cout<<" Entrer le denominateur : ";
            cin>>n1.den;
            cout<<endl;
            rationnel(n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Division de deux rationnels qui donne un rationnel (si la division est possible) : ";
            Division(n,n1);
             break;
        case 8:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<endl;
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<"Entrer l'entier : ";
            cin>>m.entier;
            cout<<endl;
            cout<<endl;
            cout<<" Division d'un rationnel et d'un entier qui donne un rationnel (si possible) : ";
            Division(n,m.entier);
            break;
        case 9:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            demandeRationnel_Normalise(n.num,n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            demandeRationnel_Normalise(n1.num,n1.den);
            cout<<endl;
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Division de deux rationnels normalises qui donne un rationnel normalise (si possible) : ";
            Division_Normalise(n,n1);
            break;
        case 10:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n.num;
            cout<<" Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n1.num;
            cout<<" Entrer le denominateur : ";
            cin>>n1.den;
            cout<<endl;
            rationnel(n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Soustraction de deux rationnels qui donne un rationnel : ";
            soustraire(n,n1);
            break;
        case 11:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<endl;
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<"Entrer l'entier : ";
            cin>>m.entier;
            cout<<endl;
            cout<<endl;
            cout<<" Soustraction d'un rationnel et d'un entier qui donne un rationnel. ";
            soustraire(n,m.entier);
            break;
        case 12:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            demandeRationnel_Normalise(n.num,n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            demandeRationnel_Normalise(n1.num,n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            cout<<endl;
            cout<<endl;
            cout<<" Soustraction de deux rationnels normalises qui donne un rationnel normalise. ";
            soustraire_Normalise(n,n1);
            break;
        case 13:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<"  L'inverse d'un rationnel qui donne un rationnel (si l'operation est possible) : ";
            inverse(n);
            break;
        case 14:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<endl;
            cout<<" La normalisation d'un rationnel qui donne le rationnel normalise correspondant : ";
            Normalisation(n);
            break;
        case 15:
            int table[2];
            int tab[2];
            Somme_Produit(table,tab);
            break;
        case 16:
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<"Entrer le numerateur : ";
            cin>>n.num;
            cout<<"Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<endl;
            cout<<endl;
            cout<<"  L'affichage d'un nombre rationnel sous le format num / den : ";
            afficher(n);
            break;
        case 17:
            cout<<endl;
            cout<<"----VALEURS DES TABLEAUX----"<<endl;
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n.num;
            cout<<" Entrer le denominateur : ";
            cin>>n.den;
            rationnel(n.den);
            cout<<" Premiere fraction : ";
            Affichage_Nombre(n.num,n.den);
            cout<<endl;
            cout<<" Entrer le numerateur : ";
            cin>>n1.num;
            cout<<" Entrer le denominateur : ";
            cin>>n1.den;
            rationnel(n1.den);
            cout<<" Deuxieme fraction : ";
            Affichage_Nombre(n1.num,n1.den);
            Comparer(n,n1);

            break;
        case 18:
            int taille;
            std::cout<<" Entrer le nombre de nombre rationnels que vous voulez saisis : ";
            cin>>taille;
            cout<<endl;
            Classement(taille);
            break;
        default:
            cout<<"Erreur de choix !";
            break;
        }



             cout<<endl;
             cout<<endl;
             cout<<"Voulez-vous continuer : ";
             cin>>second_choix;
             cout<<endl;
}while(second_choix=="Oui" || second_choix=="oui" || second_choix=="OUI");

         cout<<"FIN DE PROGRAMME "<<endl;





    return a.exec();
}
