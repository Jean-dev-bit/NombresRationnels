#ifndef STRUCTURE_H
#define STRUCTURE_H



// Définition de la structure Rationnel
struct Rationnel {
  int num;
  int den;
  int entier;
};

//Fonctions utilisées

void rationnel(int &a);
int pgcd(int x,int y);
void rationnelNormalise(int &a,int &b);
void Affichage_Nombre (int a, int b);
int demandeRationnel_Normalise (int &numr, int &denr);
Rationnel addition(Rationnel r1, Rationnel r2);
Rationnel addition(Rationnel r, int entier);
Rationnel addition_Normalise(Rationnel r1, Rationnel r2);
Rationnel multiplication(Rationnel r1, Rationnel r2);
Rationnel multiplication(Rationnel r, int entier);
Rationnel Multiplication_Normalise(Rationnel r1, Rationnel r2);
Rationnel Division(Rationnel r1, Rationnel r2);
Rationnel Division(Rationnel r, int entier);
Rationnel Division_Normalise(Rationnel r1, Rationnel r2);
Rationnel soustraire(Rationnel r1, Rationnel r2);
Rationnel soustraire(Rationnel r, int entier);
Rationnel soustraire_Normalise(Rationnel r1, Rationnel r2);
Rationnel inverse(Rationnel r);
Rationnel Normalisation(Rationnel r1);
void Somme_Produit(int Somme[],int Produit[]);
void afficher(Rationnel r);
Rationnel Comparer(Rationnel r1, Rationnel r2);
Rationnel Classement (int n);







#endif // STRUCTURE_H
