NOMBRE RATIONNELS & NOMBRE RATIONNELS NORMALISES

---Description---

Ce programme est conçu pour calculer l'addition,  la soustraction, la multiplication 
et la division entre  deux nombres rationnels, deux nombres rationnels normalisés ainsi qu'un nombre rationnel et un entier.
Il également conçu pour effectuer la conparaison de deux rationnels, le tri ou classement de plus nombres rationnels; 
la somme et la multiplication de n nombres rationnels.
Enfin, ce programme effectue la normalisation, l'inverse, l'affichage d'un nombre rationnel.

Il est écrit en C++ et utilise la bibliothèque Qt pour exécuter certaines tâches.

---Prérequis---

Pour aboutir à la réalisation, on a implémenter des fonctions, des structures et  des classes.  

Pour chaque opération effectuer le résultat s'affiche sous la forme [numérateur,dénominateur]
